﻿UPDATE PE_CommonProduct
SET StepUnit=@step
WHERE ProductNum=@drugcode